<?php

/**
 * @Project TMS HOLDINGS
 * @Author HoAnhTuan <anhtuana2k422001@gmail.com>
 * @Copyright (C) 2022 HoAnhTuan. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Sun, 20 Nov 2022 20:32:39 GMT
 */

if (!defined('NV_ADMIN'))
    die('Stop!!!');

$submenu['headbook'] = $lang_module['headbook'];
$submenu['education'] = $lang_module['education'];
$submenu['program'] = $lang_module['program'];
$submenu['week'] = $lang_module['week'];
$submenu['subjects'] = $lang_module['subjects'];
$submenu['class'] = $lang_module['class'];
$submenu['time'] = $lang_module['time'];
$submenu['teacher'] = $lang_module['teacher'];
$submenu['config'] = $lang_module['config'];
