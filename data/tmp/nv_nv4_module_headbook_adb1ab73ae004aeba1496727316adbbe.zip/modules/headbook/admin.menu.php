<?php

/**
 * @Project TMS HOLDINGS
 * @Author Ho Anh Tuan <anhtuana2k422001@gmail.com>
 * @Copyright (C) 2022 Ho Anh Tuan. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Sun, 27 Nov 2022 09:22:25 GMT
 */

if (!defined('NV_ADMIN'))
    die('Stop!!!');

$submenu['organizations'] = $lang_module['organizations'];
$submenu['department'] = $lang_module['department'];
$submenu['schools'] = $lang_module['schools'];
$submenu['grade'] = $lang_module['grade'];
$submenu['teacher'] = $lang_module['teacher'];
$submenu['times'] = $lang_module['times'];
$submenu['class'] = $lang_module['class'];
$submenu['subjects'] = $lang_module['subjects'];
$submenu['lessons'] = $lang_module['lessons'];
$submenu['distribution'] = $lang_module['distribution'];
$submenu['year'] = $lang_module['year'];
$submenu['week'] = $lang_module['week'];
$submenu['contents'] = $lang_module['contents'];
$submenu['summary'] = $lang_module['summary'];
$submenu['setting'] = $lang_module['setting'];
