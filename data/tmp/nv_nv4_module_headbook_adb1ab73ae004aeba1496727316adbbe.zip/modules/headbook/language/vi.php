<?php

/**
 * @Project TMS HOLDINGS
 * @Author Ho Anh Tuan <anhtuana2k422001@gmail.com>
 * @Copyright (C) 2022 Ho Anh Tuan. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Sun, 27 Nov 2022 09:22:25 GMT
 */

if (!defined('NV_MAINFILE'))
    die('Stop!!!');

$lang_translator['author'] = 'Ho Anh Tuan (anhtuana2k422001@gmail.com)';
$lang_translator['createdate'] = '27/11/2022, 09:22';
$lang_translator['copyright'] = '@Copyright (C) 2022 TMS Holdings. All rights reserved';
$lang_translator['info'] = '';
$lang_translator['langtype'] = 'lang_module';

$lang_module['main'] = 'Trang chính';
$lang_module['detail'] = 'Xem chi tiết';
$lang_module['search'] = 'Tìm kiếm';
