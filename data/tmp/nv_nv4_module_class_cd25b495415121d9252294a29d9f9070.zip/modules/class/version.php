<?php

/**
 * @Project TMS HOLDINGS
 * @Author Ho Anh Tuan <anhtuana2k422001@gmail.com>
 * @Copyright (C) 2022 Ho Anh Tuan. All rights reserved
 * @License GNU/GPL version 2 or any later version
 * @Createdate Wed, 07 Dec 2022 12:12:39 GMT
 */

if (!defined('NV_MAINFILE'))
    die('Stop!!!');

$module_version = array(
    'name' => 'Class',
    'modfuncs' => 'main,detail,search',
    'change_alias' => 'main,detail,search',
    'submenu' => 'main,detail,search',
    'is_sysmod' => 0,
    'virtual' => 1,
    'version' => '4.0.00',
    'date' => 'Wed, 7 Dec 2022 12:12:39 GMT',
    'author' => 'Ho Anh Tuan (anhtuana2k422001@gmail.com)',
    'uploads_dir' => array($module_name),
    'note' => ''
);
